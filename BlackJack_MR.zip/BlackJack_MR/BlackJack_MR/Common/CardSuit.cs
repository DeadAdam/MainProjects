﻿namespace BlackJack_MR.Common
{
    public enum CardSuit
    {
        Spades = 0,
        Diamonds = 1,
        Hearts = 2,
        Clubs = 3
    }
}
